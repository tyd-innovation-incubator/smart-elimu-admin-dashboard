<?php

namespace App\Package;

use Illuminate\Database\Eloquent\Model;

class Code extends Model
{
        protected $table = 'codes';

    protected $guarded  = [];


       public function codeValues()
    {
        return $this->hasMany('App\Package\CodeValues');
    }

}
