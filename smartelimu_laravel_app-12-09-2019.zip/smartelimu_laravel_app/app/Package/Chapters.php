<?php

namespace App\Package;

use Illuminate\Database\Eloquent\Model;

class Chapters extends Model 
{

    protected $table = 'chapters';
    public $timestamps = true;

    public function sections()
    {
        return $this->hasMany('App\Package\Sections', 'chapter_id');
    }

    public function subjects()
    {
        return $this->belongsTo('App\Package\Subjects');
    }

}