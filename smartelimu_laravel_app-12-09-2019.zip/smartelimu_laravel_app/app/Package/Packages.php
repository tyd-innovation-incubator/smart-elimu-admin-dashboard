<?php

namespace App\Package;

use Illuminate\Database\Eloquent\Model;

class Packages extends Model 
{

    protected $table = 'package';
    public $timestamps = true;

    public function subject()
    {
        return $this->hasMany('App\Package\Subjects', 'package_id');
    }

}