<?php

namespace App\Package;

use Illuminate\Database\Eloquent\Model;

class Sections extends Model 
{

    protected $table = 'section';
    public $timestamps = true;

    public function chapters()
    {
        return $this->belongsTo('App\Chapters');
    }

}