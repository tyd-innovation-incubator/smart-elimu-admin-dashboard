<?php

namespace App\Package;

use Illuminate\Database\Eloquent\Model;

class Examinations extends Model
{
    protected $table = 'examinations';

    protected $guarded  = [];


}
