<?php

namespace App\Package;

use Illuminate\Database\Eloquent\Model;

class Subjects extends Model 
{

    protected $table = 'subjects';
    public $timestamps = true;

    public function chapters()
    {
        return $this->hasMany('App\Package\Chapters', 'subject_id');
    }

    public function packages()
    {
        return $this->belongsTo('App\Package\Packages');
    }

}