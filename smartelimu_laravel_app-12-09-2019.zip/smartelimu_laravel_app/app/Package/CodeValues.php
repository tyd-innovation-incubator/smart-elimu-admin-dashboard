<?php

namespace App\Package;

use Illuminate\Database\Eloquent\Model;

class CodeValues extends Model
{
    protected $table = 'code_values';

    protected $guarded  = [];


       public function code()
    {
        return $this->belongsTo('App\Package\Code');
    }
}
