<?php

namespace App\Http\Controllers\Admin\Packages;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;
use Storage;
use Response;
use App\Package\Syllabus;

class SyllabusController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');

    }

    //show list of syllabus
    public function index()
    {
        $syllabus = Syllabus::latest();

        $syllabus = $syllabus->get();

        return view('admin.packages.syllabus.index', compact('syllabus'));
    }

    // show  syllabus details
    public function show($id)
    {
        $syllabus = Syllabus::findOrFail($id);

        return view('admin.packages.syllabus.show', compact('syllabus'));
    }


    // show create page
    public function create()
    {
        return view('admin.packages.syllabus.create');
    }

    // save new syllabus
    public function store(Request $request)
    {
        //validate the syllabus details

        $request->validate([
            'name' => 'required',
            'file' => 'required|file',
        ]);

        $syllabus = new Syllabus();

        $syllabus->name = $request['name'];




        //save the file

        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $filename = $request['name'].'-'.time().'.'.$file->getClientOriginalExtension();

            $location = 'files/syllabus/';
            $file->move($location,$filename);

            $syllabus->file = $filename;

        }

        $syllabus->save();
        // set flash data with success message
        Session::flash('success', ' Successfully uploaded !');

        return redirect(route('admin.syllabus.index'));
    }

    // show edit page
    public function edit($id)
    {
        $syllabus = Syllabus::find($id);

        return view('admin.packages.syllabus.edit', compact('syllabus'));
    }

    //save updates
    public function update(Request $request, $id)
    {
        $syllabus = Syllabus::find($id);

        //validate the syllabus details

        $request->validate([
            'name' => 'required',
            'file' => 'file',

        ]);

        $syllabus->name = $request['name'];


        //save the file

        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $filename = $request['name'].'-'.time().'.'.$file->getClientOriginalExtension();

            $location = 'files/syllabus/';
            $file->move($location,$filename);

            $oldFilename = $syllabus->file;

            //update the database
            $syllabus->file = $filename;

            //delete the old file
            $myFile = '/files/syllabus/'.$oldFilename;
            Storage::disk('file-root')->delete($myFile);

        }

        $syllabus->save();
        // set flash data with success message
        Session::flash('success', 'Successfully updated !');
        return redirect(route('admin.syllabus.index'));
    }

    //detele an syllabus
    public function destroy($id)
    {
        $syllabus = Syllabus::find($id);

        //delete the file in the folder
        $myFile = '/files/syllabus/'.$syllabus->file;
        Storage::disk('file-root')->delete($myFile);


        //delete the file in the database
        $syllabus->delete();



        // set flash data with success message
        Session::flash('success', 'Successfully deleted !');
        return redirect(route('admin.syllabus.index'));
    }

}
