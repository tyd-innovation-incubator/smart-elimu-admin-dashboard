<?php

namespace App\Http\Controllers\Admin\Packages;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;
use App\Package\Code;
use App\Package\CodeValues;

class CodesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');

    }

    #show list of codes
    public function index()
    {
        $codes = Code::latest()->get();

        return view('admin.packages.codes.index', compact('codes'));
    }


    #create new code
    public function create()
    {
        return view('admin.packages.codes.create');
    }

    public function store(Request $request)
    {
        //validate the category details
        $request->validate([
            'name' => 'required',
        ]);

        $code = new Code;

        $code->name = $request['name'];
        $code->save();

        //add new codes values

        if (!empty($request['codevalue1'])) {
            $codeValue = new CodeValues;

            $codeValue->values = $request['codevalue1'];

            $code->codeValues()->save($codeValue);
        }

        if (!empty($request['codevalue2'])) {
            $codeValue = new CodeValues;

            $codeValue->values = $request['codevalue2'];

            $code->codeValues()->save($codeValue);
        }

        if (!empty($request['codevalue3'])) {
            $codeValue = new CodeValues;

            $codeValue->values = $request['codevalue3'];

            $code->codeValues()->save($codeValue);
        }


        // set flash data with success message
        Session::flash('success', ' Successfully uploaded !');

        return redirect(route('admin.codes.index'));
    }

    //Show list of codevalues from a code
    public function show($id)
    {
        $code = Code::find($id);

        return view('admin.packages.codes.show', compact('code'));
    }

    #edit the code
    public function edit($id)
    {

        $code = Code::find($id);

        return view('admin.packages.codes.edit', compact('code'));
    }

    #save the code
    public function update(Request $request, $id)
    {
        //validate the category details
        $request->validate([
            'name' => 'required',
        ]);

        $code = Code::find($id);

        $code->name = $request['name'];
        $code->save();

        // set flash data with success message
        Session::flash('success', ' Successfully Updated !');

        return redirect(route('admin.codes.show',[$code->id]));
    }

    //delete code
    public function deleteCode($id)
    {
        $code = Code::find($id);

        //add how to delete the photos in the photos table
        foreach ($code->codeValues as $value) {

            //delete  values

            $value->delete();
        }

        $code->delete();

        // set flash data with success message
        Session::flash('success', 'Successfully deleted !');
        return redirect(route('admin.codes.index'));

    }


    #function to  create new value
    public function createValue($id)
    {
        $code_id = Code::find($id);

        return view('admin.packages.codes.createValue', compact('code_id'));
    }

    public function storeValue(Request $request,$id)
    {
        //validate the category details
        $request->validate([
            'value' => 'required',
        ]);

        $code= Code::find($id);

        $codeValue = new CodeValues;

        $codeValue->values =  $request['value'];

        $code->codeValues()->save($codeValue);


        $code_id = $request['code_id'];

        // set flash data with success message
        Session::flash('success', 'Successfully Added !');
        return redirect(route('admin.codes.show',[$code_id]));


    }

    #function to  edit value
    public function editValue($id)
    {

        $value = CodeValues::find($id);

        $code_id = $value->code_id;

        return view('admin.packages.codes.editValue', compact(['code_id','value']));
    }


    public function updateValue(Request $request, $id)
    {
        //validate the category details
        $request->validate([
            'value' => 'required',
        ]);

        $codeValue = CodeValues::find($id);

        $codeValue->code_id = $request['code_id'];
        $codeValue->values = $request['value'];

        $codeValue->save();

        $code_id = $request['code_id'];

        // set flash data with success message
        Session::flash('success', 'Successfully updated !');
        return redirect(route('admin.codes.show',[$code_id]));


    }

    public function deleteValue($id)
    {
        $value = CodeValues::find($id);

        $value->delete();

        // set flash data with success message
        Session::flash('success', 'Successfully deleted !');
        return redirect()->back();

    }
}
