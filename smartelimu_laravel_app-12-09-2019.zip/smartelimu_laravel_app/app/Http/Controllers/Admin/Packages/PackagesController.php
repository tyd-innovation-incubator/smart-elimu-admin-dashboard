<?php

namespace App\Http\Controllers\Admin\Packages;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;
use Image;
use App\Package\Packages;
use App\Package\Subjects;
use App\Package\Code;
use App\Package\CodeValues;
use Storage;

class PackagesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
        $this->middleware('permission:package-list|package-create|package-edit|package-delete', ['only' => ['index','show']]);
        $this->middleware('permission:package-create', ['only' => ['create','store']]);
        $this->middleware('permission:package-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:package-delete', ['only' => ['delete']]);

    }

    #show list of  packages
    public function index()
    {
        $packages = Packages::latest()->get();

        return view('admin.packages.packages.index', compact('packages'));
    }


    #create new  package
    public function create()
    {

        $classCode = Code::find(5);
        $categoryCode = Code::find(3);

        return view('admin.packages.packages.create',compact(['classCode','categoryCode']));
    }


    // save new packages
    public function store(Request $request)
    {
        //validate the packages details
        $request->validate([
            'name' => 'required',
            'category' => 'required',
            'image' => 'required|image|max:2048',
            'description' => 'required',
            'price' => 'required',
            'status' => 'required'
        ]);

        $package = new Packages;

        $package->name = $request['name'];
        $package->category = $request['category'];
        $package->description = $request['description'];
        $package->price = $request['price'];
        $package->status = $request['status'];

        //save the image

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('img/packages/'.$filename);
            Image::make($image)->save($location);

            $package->image = $filename;

        }

        $package->save();

        // set flash data with success message
        Session::flash('success', ' Successfully uploaded !');

        return redirect(route('admin.packages.index'));
    }

    //Show  package
    public function show($id)
    {
        $package = Packages::find($id);

        return view('admin.packages.packages.show', compact('package'));
    }

    #edit the  package
    public function edit($id)
    {

        $package = Packages::find($id);
        $classCode = Code::find(5);
        $categoryCode = Code::find(3);

        return view('admin.packages.packages.edit', compact(['package','classCode','categoryCode']));
    }

    #save the package
    public function update(Request $request, $id)
    {

        //validate the packages details
        $request->validate([
            'name' => 'required',
            'category' => 'required',
            'image' => 'image|max:2048',
            'description' => 'required',
            'price' => 'required',
            'status' => 'required'
        ]);

        $package = Packages::find($id);

        $package->name = $request['name'];
        $package->category = $request['category'];
        $package->description = $request['description'];
        $package->price = $request['price'];
        $package->status = $request['status'];

        //save the image
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('img/packages/'.$filename);
            Image::make($image)->save($location);
            //grab the old image
            $oldFilename = $package->image;

            //update the database
            $package->image = $filename;

            //delete the old photo
            Storage::delete('packages/'.$oldFilename);

        }
        $package->save();

        // set flash data with success message
        Session::flash('success', ' Successfully Updated !');

        return redirect(route('admin.packages.show',[$package->id]));
    }

    //delete package
    public function delete($id)
    {
        $package = Packages::find($id);

        //delete the image in the image folder
        Storage::delete('packages/'.$package->image);


        $package->delete();

        // set flash data with success message
        Session::flash('success', 'Successfully deleted !');
        return redirect(route('admin.packages.index'));

    }
}
