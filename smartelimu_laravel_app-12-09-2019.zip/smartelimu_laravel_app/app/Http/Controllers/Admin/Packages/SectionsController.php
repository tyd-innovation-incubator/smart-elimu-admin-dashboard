<?php

namespace App\Http\Controllers\Admin\Packages;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;
use App\Package\Sections;
use App\Package\Chapters;

class SectionsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');

    }


    #create new   sections
    public function create($id)
    {
        $chapter_id = Chapters::find($id);
        return view('admin.packages.sections.create',compact('chapter_id'));
    }


    // save new sections
    public function store(Request $request, $id)
    {
        //validate the sections details
        $request->validate([
            'name' => 'required',
            'content' => 'required',
            'video_file' => 'required|url',
            'audio_file' => 'required|url'
        ]);

        $section = new Sections;

        $section->name = $request['name'];
        $section->content = $request['content'];
        $section->video_file = $request['video_file'];
        $section->audio_file = $request['audio_file'];

        $chapter = Chapters::find($id);

        $chapter->sections()->save($section);


        // set flash data with success message
        Session::flash('success', ' Successfully uploaded !');

        return redirect(route('admin.chapters.show',[$chapter->id]));
    }

    //Show  section
    public function show($id)
    {
        $section = Sections::find($id);

        return view('admin.packages.sections.show', compact('section'));
    }

    #edit the  section
    public function edit($id)
    {

        $section = Sections::find($id);

        $chapter_id = $section->chapter_id;

        return view('admin.packages.sections.edit', compact(['section','chapter_id']));
    }

    #save the section
    public function update(Request $request, $id)
    {

        //validate the section details
        $request->validate([
            'name' => 'required',
            'content' => 'required',
            'video_file' => 'url',
            'audio_file' => 'url'
        ]);

        $section = Sections::find($id);

        $section->name = $request['name'];
        $section->content = $request['content'];
        $section->video_file = $request['video_file'];
        $section->audio_file = $request['audio_file'];

        $section->save();

        // set flash data with success message
        Session::flash('success', ' Successfully Updated !');

        return redirect(route('admin.sections.show',[$section->id]));
    }

    //delete section
    public function delete($id)
    {
        $section = Sections::find($id);

        $section->delete();

        // set flash data with success message
        Session::flash('success', 'Successfully deleted !');
        return redirect()->back();

    }
}
