<?php

namespace App\Http\Controllers\Admin\Packages;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;
use App\Package\Subjects;
use App\Package\Chapters;

class ChaptersController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');

    }


    #create new  chapters
    public function create($id)
    {
        $subject_id = Subjects::find($id);
        return view('admin.packages.chapters.create',compact('subject_id'));
    }


    // save new chapters
    public function store(Request $request, $id)
    {
        //validate the chapters details
        $request->validate([
            'name' => 'required',
            'description' => 'required',
            'status' => 'required'
        ]);

        $chapter = new Chapters;

        $chapter->name = $request['name'];
        $chapter->description = $request['description'];
        $chapter->status = $request['status'];

        $subject = Subjects::find($id);

        $subject->chapters()->save($chapter);


        // set flash data with success message
        Session::flash('success', ' Successfully uploaded !');

        return redirect(route('admin.subjects.show',[$subject->id]));
    }

    //Show  chapters
    public function show($id)
    {
        $chapter = Chapters::find($id);

        return view('admin.packages.chapters.show', compact('chapter'));
    }

    #edit the  chapter
    public function edit($id)
    {

        $chapter = Chapters::find($id);

        $subject_id = $chapter->subject_id;

        return view('admin.packages.chapters.edit', compact(['chapter','subject_id']));
    }

    #save the chapter
    public function update(Request $request, $id)
    {

        //validate the chapter details
        $request->validate([
            'name' => 'required',
            'description' => 'required',
            'status' => 'required'
        ]);

        $chapter = Chapters::find($id);

        $chapter->name = $request['name'];
        $chapter->description = $request['description'];
        $chapter->status = $request['status'];
        $chapter->subject_id = $request['subject_id'];

        $chapter->save();

        // set flash data with success message
        Session::flash('success', ' Successfully Updated !');

        return redirect(route('admin.chapters.show',[$chapter->id]));
    }

    //delete chapter
    public function delete($id)
    {
        $chapter = Chapters::find($id);

        $chapter->delete();

        // set flash data with success message
        Session::flash('success', 'Successfully deleted !');
        return redirect()->back();

    }
}
