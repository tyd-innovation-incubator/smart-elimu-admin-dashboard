<?php

namespace App\Http\Controllers\Admin\Packages;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;
use App\Package\Subjects;
use App\Package\Packages;

class SubjectsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');

    }


    #create new  subjects
    public function create($id)
    {
        $package_id = Packages::find($id);
        return view('admin.packages.subjects.create',compact('package_id'));
    }


    // save new subjects
    public function store(Request $request, $id)
    {
        //validate the subjects details
        $request->validate([
            'name' => 'required',
            'description' => 'required',
            'status' => 'required'
        ]);

        $subject = new Subjects;

        $subject->name = $request['name'];
        $subject->description = $request['description'];
        $subject->status = $request['status'];

        $package = Packages::find($id);

        $package->subject()->save($subject);


        // set flash data with success message
        Session::flash('success', ' Successfully uploaded !');

        return redirect(route('admin.packages.show',[$package->id]));
    }

    //Show  subjects
    public function show($id)
    {
        $subject = Subjects::find($id);

        return view('admin.packages.subjects.show', compact('subject'));
    }

    #edit the  subject
    public function edit($id)
    {

        $subject = Subjects::find($id);

        $package_id = $subject->package_id;

        return view('admin.packages.subjects.edit', compact(['subject','package_id']));
    }

    #save the subject
    public function update(Request $request, $id)
    {

        //validate the packages details
        $request->validate([
            'name' => 'required',
            'description' => 'required',
            'status' => 'required'
        ]);

        $subject = Subjects::find($id);

        $subject->name = $request['name'];
        $subject->description = $request['description'];
        $subject->status = $request['status'];
        $subject->package_id = $request['package_id'];

        $subject->save();

        // set flash data with success message
        Session::flash('success', ' Successfully Updated !');

        return redirect(route('admin.subjects.show',[$subject->id]));
    }

    //delete subject
    public function delete($id)
    {
        $subject = Subjects::find($id);

        $subject->delete();

        // set flash data with success message
        Session::flash('success', 'Successfully deleted !');
        return redirect()->back();

    }
}
