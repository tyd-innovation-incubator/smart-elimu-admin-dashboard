<?php

namespace App\Http\Controllers\Admin\Packages;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;
use Storage;
use App\Package\Examinations;
use App\Package\Code;

class ExaminationsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');

    }

    //show list of examinations
    public function index()
    {
        $exams = Examinations::latest();

        $exams = $exams->get();

        return view('admin.packages.exams.index', compact('exams'));
    }

    // show  examinations details
    public function show($id)
    {
        $exam = Examinations::findOrFail($id);

        return view('admin.packages.exams.show', compact('exam'));
    }


    // show create page
    public function create()
    {
        $classCode = Code::find(5);

        $current_year = date('Y');
        $years = range(1960, $current_year);

        return view('admin.packages.exams.create',compact(['classCode','years']));
    }

    // save new examination
    public function store(Request $request)
    {
        //validate the exams details

        $request->validate([
            'subject' => 'required',
            'class' => 'required',
            'year' => 'required',
            'file' => 'required|file',
        ]);

        $exam = new Examinations();

        $exam->subject = $request['subject'];
        $exam->class = $request['class'];
        $exam->year = $request['year'];

        //save the file

        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $filename = $request['subject'].'-'.time().'.'.$file->getClientOriginalExtension();

            $location = 'files/exams/';
            $file->move($location,$filename);

            $exam->file = $filename;

        }

        $exam->save();
        // set flash data with success message
        Session::flash('success', ' Successfully uploaded !');

        return redirect(route('admin.exams.index'));
    }

    // show edit page
    public function edit($id)
    {
        $exam = Examinations::find($id);
        $classCode = Code::find(5);


        $current_year = date('Y');
        $years = range(1960, $current_year);

        return view('admin.packages.exams.edit', compact(['exam','classCode','years']));
    }

    //save updates
    public function update(Request $request, $id)
    {
        $exam = Examinations::find($id);

        //validate the syllabus details

        $request->validate([
            'subject' => 'required',
            'class' => 'required',
            'year' => 'required',
            'file' => 'file',
        ]);

        $exam->subject = $request['subject'];
        $exam->class = $request['class'];
        $exam->year = $request['year'];



        //save the file

        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $filename = $request['subject'].'-'.time().'.'.$file->getClientOriginalExtension();

            $location = 'files/exams/';
            $file->move($location,$filename);

            $oldFilename = $exam->file;

            //update the database
            $exam->file = $filename;

            //delete the old file
            $myFile = '/files/exams/'.$oldFilename;
            Storage::disk('file-root')->delete($myFile);

        }

        $exam->save();
        // set flash data with success message
        Session::flash('success', 'Successfully updated !');
        return redirect(route('admin.exams.index'));
    }

    //detele an exams
    public function destroy($id)
    {
        $exam = Examinations::find($id);

        //delete the file in the folder
        $myFile = '/files/exams/'.$exam->file;
        Storage::disk('file-root')->delete($myFile);


        //delete the file in the database
        $exam->delete();

        // set flash data with success message
        Session::flash('success', 'Successfully deleted !');
        return redirect(route('admin.exams.index'));
    }

}
