<?php

namespace App\Http\Controllers\Admin\Information;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;
use Image;
use Storage;
use App\Information\Testimony;

class TestimonyController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');

    }

    //show list of testimony
    public function index()
    {
        $testimonies = Testimony::latest();

        $testimonies = $testimonies->get();

        return view('admin.information.testimony.index', compact('testimonies'));
    }

    // show  testimony details
    public function show($id)
    {
        $testimony = Testimony::findOrFail($id);

        return view('admin.information.testimony.show', compact('testimony'));
    }

    // show create page
    public function create()
    {
        return view('admin.information.testimony.create');
    }

    // save new testimony
    public function store(Request $request)
    {
        //validate the testimony details

        $request->validate([
            'name' => 'required',
            'occupation' => 'required',
            'message' => 'required',
            'status' => 'required',
            'image' => 'required|image|max:2048',
        ]);

        $testimony = new Testimony();

        $testimony->name = $request['name'];
        $testimony->occupation = $request['occupation'];
        $testimony->message = $request['message'];
        $testimony->status = $request['status'];


        //save the image

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('img/testimonials/' . $filename);
            Image::make($image)->resize(100,100)->save($location);

            $testimony->image = $filename;

        }

        $testimony->save();
        // set flash data with success message
        Session::flash('success', ' Successfully uploaded !');

        return redirect(route('admin.testimony.index'));
    }

    // show edit page
    public function edit($id)
    {
        $testimony = Testimony::find($id);

        return view('admin.information.testimony.edit', compact('testimony'));
    }

    //save updates
    public function update(Request $request, $id)
    {
        $testimony = Testimony::find($id);

        //validate the testimony details

        $request->validate([
            'name' => 'required',
            'occupation' => 'required',
            'message' => 'required',
            'status' => 'required',
            'image' => 'image|max:2048',
        ]);

        $testimony->name = $request['name'];
        $testimony->occupation = $request['occupation'];
        $testimony->message = $request['message'];
        $testimony->status = $request['status'];

        //save the image
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('img/testimonials/' . $filename);
            Image::make($image)->resize(100,100)->save($location);
            //grab the old image
            $oldFilename = $testimony->image;

            //update the database
            $testimony->image = $filename;

            //delete the old photo
            Storage::delete('testimonials/' . $oldFilename);

        }

        $testimony->save();
        // set flash data with success message
        Session::flash('success', 'Successfully updated !');
        return redirect(route('admin.testimony.index'));
    }

    //detele an image
    public function destroy($id)
    {
        $testimony = Testimony::find($id);

        //delete the image in the image folder
        Storage::delete('testimonials/' . $testimony->image);


        //delete the image name in the database
        $testimony->delete();

        // set flash data with success message
        Session::flash('success', 'Successfully deleted !');
        return redirect(route('admin.testimony.index'));
    }

}
