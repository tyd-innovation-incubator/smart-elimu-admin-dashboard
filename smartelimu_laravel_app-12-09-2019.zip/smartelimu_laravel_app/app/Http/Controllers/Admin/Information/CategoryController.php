<?php

namespace App\Http\Controllers\Admin\Information;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;

use App\Information\Category;

class CategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');

    }

    //show list of category
    public function index()
    {
        $categories = Category::latest();

        $categories = $categories->get();

        return view('admin.information.category.index', compact('categories'));
    }

    // show create page
    public function create()
    {
        return view('admin.information.category.create');
    }

    // save new category
    public function  store(Request $request)
    {
        //validate the category details

        $request->validate([
            'name' => 'required'
        ]);

        $category = new category();

        $category->name = $request['name'];

        $category->save();
        // set flash data with success message
        Session::flash('success', ' Successfully uploaded !');

        return redirect(route('admin.category.index'));
    }

    // show edit page
    public function edit($id)
    {
        $category = Category::find($id);

        return view('admin.information.category.edit', compact('category'));
    }

    //save updates
    public function update(Request $request, $id)
    {
        $category = Category::find($id);

        //validate the partner details

        $request->validate([
            'name' => 'required'
        ]);

        //save data to the database
        $category = category::find($id);

        $category->name = $request['name'];


        $category->save();
        // set flash data with success message
        Session::flash('success', 'Successfully updated !');
        return redirect(route('admin.category.index'));
    }

    //detele  category
    public function destroy($id)
    {
        $category = Category::find($id);

        //delete  in the database
        $category->delete();

        // set flash data with success message
        Session::flash('success', 'Successfully deleted !');
        return redirect(route('admin.category.index'));
    }

}
