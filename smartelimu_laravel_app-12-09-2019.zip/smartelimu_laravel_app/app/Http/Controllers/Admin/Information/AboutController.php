<?php

namespace App\Http\Controllers\Admin\Information;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;
use App\Information\About;

class AboutController extends Controller
{
    //access only admin guard
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    //access about information
    public  function index()
    {
        $about = About::first();


        return view('admin.information.about.index',compact('about'));
    }

    //access edit page
    public function edit()
    {
        $about = About::first();

        return view('admin.information.about.edit',compact('about'));
    }

    public function update(Request $request, $id)
    {
        $about = About::find($id);

        //validate the news details

        $request->validate([
            'introduction' => 'required',
            'mission' => 'required',
            'vision' => 'required',
            'pioneers' => 'required'
        ]);


        $about->introduction = $request['introduction'];
        $about->mission = $request['mission'];
        $about->vision = $request['vision'];
        $about->pioneers = $request['pioneers'];

        //save in the database
        $about->save();


        // set flash data with success message
        Session::flash('success', 'Successfully updated !  ');

        return redirect(route('admin.about.index'));
    }

}
