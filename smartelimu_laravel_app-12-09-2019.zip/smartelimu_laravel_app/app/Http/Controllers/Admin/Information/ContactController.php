<?php

namespace App\Http\Controllers\Admin\Information;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Information\Contact;
use Session;

class ContactController extends Controller
{
    //access only admin guard
    public function __construct()
    {
        $this->middleware('auth:admin');

    }

    //access contact information
    public  function index()
    {
        $contact = Contact::first();

        return view('admin.information.contact.index',compact('contact'));
    }

    //access edit page
    public function edit()
    {
        $contact = Contact::first();

        return view('admin.information.contact.edit',compact('contact'));
    }

    public function update(Request $request, $id)
    {
        $contact = contact::find($id);

        //validate the news details

        $request->validate([
            'email' => 'required|email',
            'location' => 'required',
            'address' => 'required',
            'mobile1' => 'required',
            'mobile2' => 'required',
            'facebook' => 'required|url',
            'twitter' => 'required|url',
            'youtube' => 'required|url',
            'instagram' => 'required|url',
            'linkedin' => 'required|url',


        ]);


        $contact->email = $request['email'];
        $contact->location = $request['location'];
        $contact->address = $request['address'];
        $contact->mobile1 = $request['mobile1'];
        $contact->mobile2 = $request['mobile2'];
        $contact->facebook = $request['facebook'];
        $contact->twitter = $request['twitter'];
        $contact->youtube = $request['youtube'];
        $contact->instagram = $request['instagram'];
        $contact->linkedin = $request['linkedin'];

        //save in the database
        $contact->save();


        // set flash data with success message
        Session::flash('success', 'Successfully updated !  ');

        return redirect(route('admin.contact.index'));
    }

}
