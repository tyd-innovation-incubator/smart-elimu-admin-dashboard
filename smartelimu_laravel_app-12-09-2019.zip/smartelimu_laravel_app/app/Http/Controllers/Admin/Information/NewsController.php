<?php

namespace App\Http\Controllers\Admin\Information;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;
use Image;
use Storage;
use App\Information\News;
use App\Information\Category;

class NewsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');

    }

    //show list of news
    public function index()
    {
        $news = News::latest();

        $news= $news->get();

        return view('admin.information.news.index', compact('news'));
    }

    // show image details
    public function show($id)
    {
        $news = News::findOrFail($id);

        return view('admin.information.news.show', compact('news'));
    }

    // show create page
    public function create()
    {
        $categories = Category::all();

        return view('admin.information.news.create',compact('categories'));
    }

    // save new news
    public function  store(Request $request)
    {
        //validate the partner details

        $request->validate([
            'title' => 'required',
            'content' => 'required',
            'category' => 'required',
            'status' => 'required',
            'image' => 'required|image|max:2048',
        ]);

        $news = new News();

        $news->title = $request['title'];
        $news->content = $request['content'];
        $news->category = $request['category'];
        $news->status = $request['status'];

        //save the image

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('img/news/'.$filename);
            Image::make($image)->resize(770,770)->save($location);

            $news->image = $filename;

        }

        $news->save();
        // set flash data with success message
        Session::flash('success', ' Successfully uploaded !');

        return redirect(route('admin.news.index'));
    }

    // show edit page
    public function edit($id)
    {
        $news = News::find($id);
        $categories = Category::all();

        return view('admin.information.news.edit', compact(['news','categories']));
    }

    //save updates
    public function update(Request $request, $id)
    {
        $news = News::find($id);

        //validate the news details

        $request->validate([
            'title' => 'required',
            'content' => 'required',
            'category' => 'required',
            'status' => 'required',
            'image' => 'image|max:2048',
        ]);

        $news->title = $request['title'];
        $news->content = $request['content'];
        $news->category = $request['category'];
        $news->status = $request['status'];

        //save the image
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('img/news/'.$filename);
            Image::make($image)->resize(770,770)->save($location);
            //grab the old image
            $oldFilename = $news->image;

            //update the database
            $news->image = $filename;

            //delete the old photo
            Storage::delete('news/'.$oldFilename);

        }

        $news->save();
        // set flash data with success message
        Session::flash('success', 'Successfully updated !');
        return redirect(route('admin.news.index'));
    }

    //detele an image
    public function destroy($id)
    {
        $news = News::find($id);

        //delete the image in the image folder
        Storage::delete('news/'.$news->image);


        //delete the image name in the database
        $news->delete();

        // set flash data with success message
        Session::flash('success', 'Successfully deleted !');
        return redirect(route('admin.news.index'));
    }

}
