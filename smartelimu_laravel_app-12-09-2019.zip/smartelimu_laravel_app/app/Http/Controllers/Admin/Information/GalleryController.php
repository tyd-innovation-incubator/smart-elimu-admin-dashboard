<?php

namespace App\Http\Controllers\Admin\Information;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;
use Image;
use Storage;

use App\Information\Gallery;

class GalleryController extends Controller
{
     public function __construct()
    {
    $this->middleware('auth:admin');

    }

    //show list of imaages
    public function index()
    {
        $galleries = Gallery::latest();

        $galleries= $galleries->get();

        return view('admin.information.gallery.index', compact('galleries'));
    }

    // show image details
    public function show($id)
    {
        $gallery = Gallery::findOrFail($id);

        return view('admin.information.gallery.show', compact('gallery'));
    }

    // show create page
    public function create()
    {
        return view('admin.information.gallery.create');
    }

    // save new image
    public function  store(Request $request)
    {
        //validate the news details

        $request->validate([
            'caption' => 'required',
            'image' => 'required|image|max:2048',
        ]);

        $gallery = new Gallery();

        $gallery->caption = $request['caption'];

        //save the image

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('img/gallery/'.$filename);
            Image::make($image)->resize(1080,720)->save($location);

            $gallery->image = $filename;

        }

        $gallery->save();
        // set flash data with success message
        Session::flash('success', ' Successfully uploaded !');

        return redirect(route('admin.gallery.index'));
    }

    // show edit page
    public function edit($id)
    {
        $gallery = Gallery::find($id);

        return view('admin.information.gallery.edit', compact('gallery'));
    }

    //save updates
    public function update(Request $request, $id)
    {
        $gallery = Gallery::find($id);

        //validate the news details

        $request->validate([
            'caption' => 'required',
            'image' => 'image|max:2048',
        ]);

        //save data to the database
        $gallery = Gallery::find($id);

        $gallery->caption = $request['caption'];

        //save the image
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('img/gallery/'.$filename);
            Image::make($image)->resize(1080,720)->save($location);
            //grab the old image
            $oldFilename = $gallery->image;

            //update the database
            $gallery->image = $filename;

            //delete the old photo
            Storage::delete('gallery/'.$oldFilename);

        }

        $gallery->save();
        // set flash data with success message
        Session::flash('success', 'Successfully updated !');
        return redirect(route('admin.gallery.index'));
    }

    //detele an image
    public function destroy($id)
    {
        $gallery = Gallery::find($id);

        //delete the image in the image folder
        Storage::delete('gallery/'.$gallery->image);


        //delete the image name in the database
        $gallery->delete();

        // set flash data with success message
        Session::flash('success', 'Successfully deleted !');
        return redirect(route('admin.gallery.index'));
    }

}
