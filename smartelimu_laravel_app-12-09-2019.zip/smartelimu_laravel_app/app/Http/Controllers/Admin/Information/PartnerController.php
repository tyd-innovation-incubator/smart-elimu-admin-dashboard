<?php

namespace App\Http\Controllers\Admin\Information;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;
use Image;
use Storage;
use App\Information\Partner;

class PartnerController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');

    }

    //show list of partner
    public function index()
    {
        $partners = Partner::latest();

        $partners= $partners->get();

        return view('admin.information.partners.index', compact('partners'));
    }

    // show create page
    public function create()
    {
        return view('admin.information.partners.create');
    }

    // save new partner
    public function  store(Request $request)
    {
        //validate the partner details

        $request->validate([
            'name' => 'required',
            'image' => 'required|image|max:2048',
        ]);

        $partner = new Partner();

        $partner->name = $request['name'];

        //save the image

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('img/partners/'.$filename);
            Image::make($image)->resize(100,100)->save($location);

            $partner->image = $filename;

        }

        $partner->save();
        // set flash data with success message
        Session::flash('success', ' Successfully uploaded !');

        return redirect(route('admin.partner.index'));
    }

    // show edit page
    public function edit($id)
    {
        $partner = Partner::find($id);

        return view('admin.information.partners.edit', compact('partner'));
    }

    //save updates
    public function update(Request $request, $id)
    {
        $partner = Partner::find($id);

        //validate the partner details

        $request->validate([
            'name' => 'required',
            'image' => 'image|max:2048',
        ]);

        //save data to the database
        $partner = Partner::find($id);

        $partner->name = $request['name'];

        //save the image
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('img/partners/'.$filename);
            Image::make($image)->resize(100,100)->save($location);
            //grab the old image
            $oldFilename = $partner->image;

            //update the database
            $partner->image = $filename;

            //delete the old photo
            Storage::delete('partners/'.$oldFilename);

        }

        $partner->save();
        // set flash data with success message
        Session::flash('success', 'Successfully updated !');
        return redirect(route('admin.partner.index'));
    }

    //detele an image
    public function destroy($id)
    {
        $partner = Partner::find($id);

        //delete the image in the image folder
        Storage::delete('partners/'.$partner->image);


        //delete the image name in the database
        $partner->delete();

        // set flash data with success message
        Session::flash('success', 'Successfully deleted !');
        return redirect(route('admin.partner.index'));
    }

}
