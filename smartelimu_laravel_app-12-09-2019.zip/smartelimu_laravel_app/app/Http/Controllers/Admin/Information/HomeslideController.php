<?php

namespace App\Http\Controllers\Admin\Information;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;
use Image;
use Storage;
use App\Information\HomeSlide;

class HomeslideController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');

    }

    public function  demo()
    {
    }

    //show list of homeslide
    public function index()
    {
        $homeslides = Homeslide::latest();

        $homeslides = $homeslides->get();

        return view('admin.information.homeslide.index', compact('homeslides'));
    }

    // show image details
    public function show($id)
    {
        $homeslide = HomeSlide::findOrFail($id);

        return view('admin.information.homeslide.show', compact('homeslide'));
    }

    // show create page
    public function create()
    {

        return view('admin.information.homeslide.create');
    }

    // save new homeslide
    public function  store(Request $request)
    {
        //validate the homeslide details

        $request->validate([
            'title' => 'required',
            'content' => 'required',
            'image' => 'required|image|max:2048',
            'status' => 'required',
        ]);

        $homeslide = new HomeSlide();

        $homeslide->title = $request['title'];
        $homeslide->content = $request['content'];
        $homeslide->status = $request['status'];

        //save the image

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('img/homeslides/'.$filename);
            Image::make($image)->resize(1500,500)->save($location);

            $homeslide->image = $filename;

        }

        $homeslide->save();
        // set flash data with success message
        Session::flash('success', ' Successfully uploaded !');

        return redirect(route('admin.homeslide.index'));
    }

    // show edit page
    public function edit($id)
    {
        $homeslide = HomeSlide::find($id);

        return view('admin.information.homeslide.edit', compact('homeslide'));
    }

    //save updates
    public function update(Request $request, $id)
    {
        $homeslide = HomeSlide::find($id);

        //validate the  homeslide details

        $request->validate([
            'title' => 'required',
            'content' => 'required',
            'image' => 'image|max:2048',
            'status' => 'required',
        ]);

        $homeslide->title = $request['title'];
        $homeslide->content = $request['content'];
        $homeslide->status = $request['status'];

        //save the image
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('img/homeslides/'.$filename);
            Image::make($image)->resize(1500,500)->save($location);
            //grab the old image
            $oldFilename = $homeslide->image;

            //update the database
            $homeslide->image = $filename;

            //delete the old photo
            Storage::delete('homeslides/'.$oldFilename);

        }

        $homeslide->save();
        // set flash data with success message
        Session::flash('success', 'Successfully updated !');
        return redirect(route('admin.homeslide.index'));
    }

    //detele an  homeslide
    public function destroy($id)
    {
        $homeslide = HomeSlide::find($id);

        //delete the image in the image folder
        Storage::delete('homeslides/'.$homeslide->image);


        //delete the image name in the database
        $homeslide->delete();

        // set flash data with success message
        Session::flash('success', 'Successfully deleted !');
        return redirect(route('admin.homeslide.index'));
    }

}
