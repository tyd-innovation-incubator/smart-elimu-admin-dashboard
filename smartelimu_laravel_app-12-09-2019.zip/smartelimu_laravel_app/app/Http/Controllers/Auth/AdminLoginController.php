<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;

class AdminLoginController extends Controller
{

    public function __construct()
    {
        $this->middleware('guest:admin', ['except' => ['logout']]);
    }

    //dashboard page for smartelimu
    public function index()
    {
        return view('admin.home.index');
    }

    public function ShowLoginForm()

    {
        return view('auth.admin-login');
    }

    public function login(Request $request)
    {
        // validate the form data
        $this->validate($request, [

            'email' => 'required|email',
            'password' => 'required|min:8'
        ]);


        // atempt to log the admin in
        if (Auth::guard('admin')->attempt(['email' => $request->email, 'password' => $request->password], $request->remember)) {
            // if successful then redirected to their intended location
            //return redirect()->intended(route('admin.dashboard'));
            return view('admin.home.index');

        }

        // if is unsuccessful then redirected back to the login page with form data

        return redirect()->back()->withInput($request->only('email', 'remember'));

    }


    //allow admin users to logout
    public function logout()
    {

        auth('admin')->logout();

        return redirect('/adminpanel/login');

    }
}
