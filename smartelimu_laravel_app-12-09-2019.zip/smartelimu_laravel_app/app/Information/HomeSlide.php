<?php

namespace App\Information;

use Illuminate\Database\Eloquent\Model;

class HomeSlide extends Model
{
    protected $table = 'homeslide';

    protected $guarded = [];
}
